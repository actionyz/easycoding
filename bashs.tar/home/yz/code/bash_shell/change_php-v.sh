#!/bin/bash
#
#下面是字体输出颜色及终端格式控制
#字体色30-37

function change_v ()  {  
	# echo $1
    rm  $1.*
	ln -s ../mods-available/$2.load && ln -s ../mods-available/$2.conf 
}  

cd /etc/apache2/mods-enabled
str=$(ls|grep  "php.*\.conf")
str=${str%%.conf*}
model='^php[0-9].[0-9]$'

if [ $# != 1 ]; then
	echo -e "\033[31mplease input one paragrams!\033[0m"
	# echo ""
else 
	if [[ "$1" =~ $model ]];then
		change_v  $str $1
		# echo -e "\033[31m红色字\033[0m"
		service apache2 restart
		echo -e "\033[32m change success!! \033[0m"
			
	else
		echo -e "\033[31minput such as php5.6 or php7.1....\033[0m"
			
	fi
	
fi




# rm  $1.*
# ln -s ../mods-available/$2.load && ln -s ../mods-available/$2.conf 


# php5.6.conf -> ../mods-available/php5.6.conf
# php5.6.load -> ../mods-available/php5.6.load
