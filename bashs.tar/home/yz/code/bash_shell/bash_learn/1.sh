#!/bin/bash



for v in ${*}; do
    iptables -A INPUT -s $v -p tcp --dport 22 -j ACCEPT
    echo -e "\033[31mAvoid ip:$v\033[0m"
done

iptables -A INPUT -m iprange --src-range ${!#::-2}-$4.255 -p tcp --dport 22 -j DROP

echo -e "\033[31mto connect local ssh\033[0m"
