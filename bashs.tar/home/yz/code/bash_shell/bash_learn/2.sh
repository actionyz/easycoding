#!/bin/bash


# l=('1','2','3')
echo ${!#::-2} 
for i in $@; do
	# l[0]='1233'
	echo $i,'\n'
done

# echo ${l[@]}
